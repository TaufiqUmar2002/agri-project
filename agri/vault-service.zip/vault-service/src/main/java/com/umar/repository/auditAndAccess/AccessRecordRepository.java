package com.umar.repository.auditAndAccess;

import com.umar.entity.auditAndAccess.AccessRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface AccessRecordRepository extends JpaRepository<AccessRecord, UUID> {
}
