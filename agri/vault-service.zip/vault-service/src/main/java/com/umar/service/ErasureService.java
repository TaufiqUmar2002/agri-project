package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.keyManagement.ErasureRegistry;
import com.umar.events.VaultEventType;
import com.umar.payload.response.vault.EraseSubjectResponse;
import com.umar.repository.keyManagement.ErasureRegistryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ErasureService {

    private final ErasureRegistryRepository erasureRegistryRepository;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;

    @Transactional
    public EraseSubjectResponse eraseSubject(String subjectRef) {
        String subjectHash = sha256(subjectRef);
        String requestId = "erase_" + UUID.randomUUID().toString().replace("-", "");

        ErasureRegistry record = new ErasureRegistry();
        record.setId(UUID.randomUUID());
        record.setSubjectHash(subjectHash);
        record.setGroup("ERASABLE");
        record.setShreddedAt(Instant.now().toString());
        record.setRequestId(requestId);

        ErasureRegistry saved = erasureRegistryRepository.save(record);
        vaultEventEmitter.emit(VaultEventType.ERASURE_COMPLETED, Map.of(
                "operation", "ERASE_SUBJECT",
                "subjectHash", subjectHash,
                "requestId", requestId,
                "recordCount", 1));
        auditRecorder.record("VAULT_ERASURE_COMPLETED", "ERASE_SUBJECT", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    @Transactional
    public EraseSubjectResponse recordErasureException(String subjectRef, String reason) {
        String subjectHash = sha256(subjectRef);
        String requestId = "exempt_" + UUID.randomUUID().toString().replace("-", "");

        ErasureRegistry record = new ErasureRegistry();
        record.setId(UUID.randomUUID());
        record.setSubjectHash(subjectHash);
        record.setGroup("EXEMPT");
        record.setShreddedAt(null);
        record.setRequestId(requestId);

        ErasureRegistry saved = erasureRegistryRepository.save(record);
        vaultEventEmitter.emit(VaultEventType.ERASURE_COMPLETED, Map.of(
                "operation", "ERASURE_EXCEPTION",
                "subjectHash", subjectHash,
                "requestId", requestId,
                "reason", reason != null ? reason : "",
                "recordCount", 1));
        auditRecorder.record("VAULT_ERASURE_EXCEPTION", "ERASURE_EXCEPTION", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    private String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to hash subject reference", e);
        }
    }

    private EraseSubjectResponse toResponse(ErasureRegistry record) {
        return EraseSubjectResponse.builder()
                .id(record.getId())
                .subjectHash(record.getSubjectHash())
                .shreddedAt(record.getShreddedAt())
                .requestId(record.getRequestId())
                .build();
    }
}