package com.umar.config;

import com.umar.entity.dataProtection.AccessPolicy;
import com.umar.repository.dataProtection.AccessPolicyRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Seeds permissive development access policies so the policy engine has rows to
 * match against. In production these are managed via the policy-management API
 * and mTLS-derived service identities.
 */
@Slf4j
@Component
public class AccessPolicySeedBootstrap implements CommandLineRunner {

    private final AccessPolicyRepository accessPolicyRepository;

    public AccessPolicySeedBootstrap(AccessPolicyRepository accessPolicyRepository) {
        this.accessPolicyRepository = accessPolicyRepository;
    }

    @Override
    public void run(String... args) {
        log.info("Ensuring development access policies exist...");

        // Dev default caller produced by VaultSecurityContext when no mTLS identity is present.
        String devCaller = "TEMP-SERVICE";
        List<String> dataClasses = List.of("PHONE", "PAYER_PHONE", "ID_NUMBER", "WALLET_NUMBER", "LEGAL_NAME", "KYC_DOCUMENT", "DOCUMENT", "SECRET", "DATA_CLASS", "GOVERNANCE");
        List<String> purposes = List.of("ACCOUNT_REGISTRATION", "PHONE_LOOKUP", "KYC_SUBMISSION", "KYC_REVIEW", "DATA_EXPORT", "GENERAL");
        List<String> operations = List.of("TOKENIZE", "DETOKENIZE", "STORE_DOCUMENT", "DOWNLOAD_DOCUMENT", "LIST_DOCUMENTS", "GET_DOCUMENT_METADATA", "DELETE_DOCUMENT", "CREATE_SECRET", "USE_SECRET", "CREATE_POLICY", "LIST_POLICIES", "APPROVAL_DECISION", "CREATE_LEGAL_HOLD", "LIFT_LEGAL_HOLD", "ERASE_SUBJECT", "APPROVE_ERASURE_EXCEPTION", "BREAK_GLASS", "ACCESS_LOG", "VERIFY_BACKUP", "ROTATE_KEY", "DEFINE_DATA_CLASS");

        int created = 0;
        int updated = 0;
        for (String dataClass : dataClasses) {
            AccessPolicy policy = accessPolicyRepository
                    .findByServiceIdentityAndDataClass(devCaller, dataClass)
                    .orElseGet(() -> {
                        AccessPolicy p = new AccessPolicy();
                        p.setServiceIdentity(devCaller);
                        p.setDataClass(dataClass);
                        p.setAllowedPurposes(new ArrayList<>());
                        p.setOperation(new ArrayList<>());
                        p.setRates("60");
                        p.setBatch("100");
                        p.setConditions("{}");
                        p.setVersions("1");
                        p.setStatus(true);
                        return p;
                    });

            if (policy.getAllowedPurposes() == null) {
                policy.setAllowedPurposes(new ArrayList<>());
            }
            if (policy.getOperation() == null) {
                policy.setOperation(new ArrayList<>());
            }

            boolean changed = mergeMissing(policy.getAllowedPurposes(), purposes)
                    | mergeMissing(policy.getOperation(), operations);

            if (policy.getId() == null) {
                accessPolicyRepository.save(policy);
                created++;
            } else if (changed) {
                accessPolicyRepository.save(policy);
                updated++;
            }
        }
        log.info("Access policy seed complete: {} created, {} updated.", created, updated);
    }

    private boolean mergeMissing(List<String> target, List<String> required) {
        if (target == null) {
            return false;
        }
        boolean changed = false;
        for (String value : required) {
            if (!target.contains(value)) {
                target.add(value);
                changed = true;
            }
        }
        return changed;
    }
}
