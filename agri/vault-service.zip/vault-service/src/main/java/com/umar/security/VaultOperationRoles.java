package com.umar.security;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * Maps vault operations to the {@link VaultRole}s permitted to perform them,
 * derived from the section 2.11 role table. Operations not listed here are
 * service-to-service operations governed by access policies (mTLS identity)
 * rather than human roles.
 */
public final class VaultOperationRoles {

    private VaultOperationRoles() {
    }

    private static final Map<String, Set<VaultRole>> OPERATION_ROLES = Map.ofEntries(
            // Policy management
            Map.entry("CREATE_POLICY", roles(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER)),
            Map.entry("LIST_POLICIES", roles(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER, VaultRole.AUDITOR)),
            // Break-glass
            Map.entry("BREAK_GLASS", roles(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER)),
            Map.entry("APPROVE_BREAK_GLASS", roles(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER)),
            // Key management
            Map.entry("ROTATE_KEY", roles(VaultRole.SECURITY_OFFICER)),
            Map.entry("APPROVE_KEY_ACTION", roles(VaultRole.KEY_CUSTODIAN)),
            // Access log
            Map.entry("ACCESS_LOG", roles(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER, VaultRole.AUDITOR)),
            // Audit chain verification
            Map.entry("VERIFY_AUDIT", roles(VaultRole.AUDITOR)),
            // Backup / drills
            Map.entry("VERIFY_BACKUP", roles(VaultRole.PLATFORM_RELIABILITY_ENGINEER)),
            // Legal hold
            Map.entry("CREATE_LEGAL_HOLD", roles(VaultRole.COMPLIANCE_OFFICER)),
            Map.entry("LIFT_LEGAL_HOLD", roles(VaultRole.COMPLIANCE_OFFICER)),
            // Erasure
            Map.entry("ERASE_SUBJECT", roles(VaultRole.COMPLIANCE_OFFICER)),
            Map.entry("APPROVE_ERASURE_EXCEPTION", roles(VaultRole.COMPLIANCE_OFFICER)),
            // Data class definition (platform team)
            Map.entry("DEFINE_DATA_CLASS", roles(VaultRole.SECURITY_OFFICER, VaultRole.ADMINISTRATOR))
    );

    /** Returns the roles permitted for an operation, or empty if role-gated mapping is absent. */
    public static Set<VaultRole> allowedRoles(String operation) {
        return OPERATION_ROLES.getOrDefault(operation, EnumSet.noneOf(VaultRole.class));
    }

    /** True if the operation has a role-based restriction defined. */
    public static boolean isRoleGated(String operation) {
        return OPERATION_ROLES.containsKey(operation);
    }

    private static Set<VaultRole> roles(VaultRole... roles) {
        return EnumSet.copyOf(java.util.Arrays.asList(roles));
    }
}
