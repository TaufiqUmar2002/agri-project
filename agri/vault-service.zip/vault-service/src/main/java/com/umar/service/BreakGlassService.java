package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.auditAndAccess.BreakGlassRequest;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.CreateBreakGlassRequest;
import com.umar.payload.response.vault.BreakGlassResponse;
import com.umar.repository.auditAndAccess.BreakGlassRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BreakGlassService {

    private final BreakGlassRequestRepository breakGlassRequestRepository;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;

    @Transactional
    public BreakGlassResponse createBreakGlassRequest(CreateBreakGlassRequest request) {
        BreakGlassRequest entity = new BreakGlassRequest();
        entity.setId(UUID.randomUUID());
        entity.setIncidentRef(request.getIncidentRef());
        entity.setScope(request.getScope());
        entity.setInvestigatorRef(request.getInvestigatorRef());
        entity.setLegalBasis(request.getLegalBasis());
        entity.setStatus("PENDING_REVIEW");
        entity.setValidUntil(request.getValidUntil());

        BreakGlassRequest saved = breakGlassRequestRepository.save(entity);
        vaultEventEmitter.emit(VaultEventType.BREAKGLASS_USED, Map.of(
                "operation", "BREAK_GLASS",
                "incidentRef", request.getIncidentRef(),
                "scope", request.getScope(),
                "investigatorRef", request.getInvestigatorRef(),
                "phase", "ISSUED",
                "recordCount", 1));
        auditRecorder.record("VAULT_BREAKGLASS_USED", "BREAK_GLASS", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    private BreakGlassResponse toResponse(BreakGlassRequest entity) {
        return BreakGlassResponse.builder()
                .id(entity.getId())
                .incidentRef(entity.getIncidentRef())
                .scope(entity.getScope())
                .investigatorRef(entity.getInvestigatorRef())
                .status(entity.getStatus())
                .validUntil(entity.getValidUntil())
                .build();
    }
}
