package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.dataProtection.AccessPolicy;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.CreatePolicyRequest;
import com.umar.payload.response.vault.PolicyResponse;
import com.umar.repository.dataProtection.AccessPolicyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class PolicyManagementService {

    private final AccessPolicyRepository accessPolicyRepository;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;

    @Transactional
    public PolicyResponse createPolicy(CreatePolicyRequest request) {
        AccessPolicy policy = new AccessPolicy();
        policy.setServiceIdentity(request.getServiceIdentity());
        policy.setDataClass(request.getDataClass());
        policy.setAllowedPurposes(request.getPurposes());
        policy.setOperation(request.getOperations());
        policy.setRates(request.getRequestsPerMinute() != null ? String.valueOf(request.getRequestsPerMinute()) : null);
        policy.setBatch(request.getMaxBatchSize() != null ? String.valueOf(request.getMaxBatchSize()) : null);
        policy.setConditions(request.getConditions());
        policy.setStatus(true);

        AccessPolicy saved = accessPolicyRepository.save(policy);
        vaultEventEmitter.emit(VaultEventType.POLICY_CHANGED, Map.of(
                "operation", "CREATE_POLICY",
                "serviceIdentity", request.getServiceIdentity(),
                "dataClass", request.getDataClass(),
                "policyId", saved.getId().toString()));
        auditRecorder.record("VAULT_POLICY_CHANGED", "CREATE_POLICY", request.getDataClass(), null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<PolicyResponse> listPolicies() {
        return accessPolicyRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    private PolicyResponse toResponse(AccessPolicy policy) {
        return PolicyResponse.builder()
                .id(policy.getId())
                .serviceIdentity(policy.getServiceIdentity())
                .dataClass(policy.getDataClass())
                .purposes(policy.getAllowedPurposes())
                .operations(policy.getOperation())
                .requestsPerMinute(policy.getRates())
                .maxBatchSize(policy.getBatch())
                .conditions(policy.getConditions())
                .status(policy.isStatus())
                .createdAt(policy.getCreatedAt())
                .build();
    }
}
