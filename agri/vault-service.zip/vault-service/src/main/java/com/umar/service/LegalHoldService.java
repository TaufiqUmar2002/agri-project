package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.keyManagement.LegalHold;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.CreateLegalHoldRequest;
import com.umar.payload.response.vault.LegalHoldResponse;
import com.umar.repository.keyManagement.LegalHoldRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class LegalHoldService {

    private final LegalHoldRepository legalHoldRepository;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;

    @Transactional
    public LegalHoldResponse createLegalHold(CreateLegalHoldRequest request) {
        LegalHold hold = new LegalHold();
        hold.setId(UUID.randomUUID());
        hold.setCaseRef(request.getCaseRef());
        hold.setAuthority(request.getAuthority());
        hold.setScope(request.getScope());
        hold.setStatus("ACTIVE");
        hold.setReviewDate(request.getReviewDate());

        LegalHold saved = legalHoldRepository.save(hold);
        vaultEventEmitter.emit(VaultEventType.LEGALHOLD_CHANGED, Map.of(
                "operation", "CREATE_LEGAL_HOLD",
                "caseRef", request.getCaseRef(),
                "authority", request.getAuthority(),
                "scope", request.getScope(),
                "holdId", saved.getId().toString()));
        auditRecorder.record("VAULT_LEGALHOLD_CHANGED", "CREATE_LEGAL_HOLD", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    @Transactional
    public LegalHoldResponse liftLegalHold(UUID holdId) {
        LegalHold hold = legalHoldRepository.findById(holdId)
                .orElseThrow(() -> new IllegalArgumentException("Legal hold not found: " + holdId));
        hold.setStatus("LIFTED");

        LegalHold saved = legalHoldRepository.save(hold);
        vaultEventEmitter.emit(VaultEventType.LEGALHOLD_CHANGED, Map.of(
                "operation", "LIFT_LEGAL_HOLD",
                "holdId", saved.getId().toString(),
                "caseRef", saved.getCaseRef(),
                "status", saved.getStatus()));
        auditRecorder.record("VAULT_LEGALHOLD_CHANGED", "LIFT_LEGAL_HOLD", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    private LegalHoldResponse toResponse(LegalHold hold) {
        return LegalHoldResponse.builder()
                .id(hold.getId())
                .caseRef(hold.getCaseRef())
                .authority(hold.getAuthority())
                .scope(hold.getScope())
                .status(hold.getStatus())
                .reviewDate(hold.getReviewDate())
                .build();
    }
}