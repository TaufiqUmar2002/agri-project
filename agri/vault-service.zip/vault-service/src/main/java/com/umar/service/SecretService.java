package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.config.EphemeralSubjectDek;
import com.umar.crypto.CryptoEngineService;
import com.umar.entity.keyManagement.Secret;
import com.umar.entity.keyManagement.SecretVersion;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.CreateSecretRequest;
import com.umar.payload.response.vault.SecretResponse;
import com.umar.payload.response.vault.UseSecretResponse;
import com.umar.repository.keyManagement.SecretRepository;
import com.umar.repository.keyManagement.SecretVersionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SecretService {

    private static final String SECRET_DATA_CLASS = "SECRET";

    private final SecretRepository secretRepository;
    private final SecretVersionRepository secretVersionRepository;
    private final CryptoEngineService cryptoEngineService;
    private final AccessSignalEmitter accessSignalEmitter;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;
    private final SecureRandom secureRandom = new SecureRandom();

    @Transactional
    public SecretResponse createSecret(CreateSecretRequest request) {
        String ref = mintRef();

        Secret secret = new Secret();
        secret.setId(UUID.randomUUID());
        secret.setRef(ref);
        secret.setName(request.getName());
        secret.setOwner(request.getOwner());
        secret.setStatus("ACTIVE");
        secretRepository.save(secret);

        int version = 1;
        String token = ref + ":" + version;
        char[] cleartext = request.getValue().toCharArray();

        try (EphemeralSubjectDek dek = cryptoEngineService.generateEphemeralDek()) {
            var payload = cryptoEngineService.encryptValue(cleartext, dek, SECRET_DATA_CLASS, ref, token);

            SecretVersion secretVersion = new SecretVersion();
            secretVersion.setId(UUID.randomUUID());
            secretVersion.setSecret(secret);
            secretVersion.setVersion(version);
            secretVersion.setCiphertext(payload.ciphertext());
            secretVersion.setNonce(payload.nonce());
            secretVersion.setWrappedDek(cryptoEngineService.wrapDek(dek));
            secretVersion.setState("ACTIVE");
            secretVersionRepository.save(secretVersion);
        } finally {
            java.util.Arrays.fill(cleartext, '\0');
        }

        accessSignalEmitter.emit("CREATE_SECRET", SECRET_DATA_CLASS, null, "SUCCESS", 1);
        vaultEventEmitter.emit(VaultEventType.SECRET_VERSIONED, Map.of(
                "operation", "CREATE_SECRET",
                "ref", ref,
                "version", version,
                "recordCount", 1));
        vaultEventEmitter.emitAccess("CREATE_SECRET", SECRET_DATA_CLASS, null, "SUCCESS", 1);
        auditRecorder.record("VAULT_SECRET_CREATED", "CREATE_SECRET", SECRET_DATA_CLASS, null, "SUCCESS", null, null);

        return SecretResponse.builder()
                .id(secret.getId())
                .ref(ref)
                .name(secret.getName())
                .owner(secret.getOwner())
                .status(secret.getStatus())
                .version(version)
                .build();
    }

    @Transactional(readOnly = true)
    public UseSecretResponse useSecret(String ref) {
        Secret secret = secretRepository.findByRef(ref)
                .orElseThrow(() -> new IllegalArgumentException("Secret not found: " + ref));

        SecretVersion version = secretVersionRepository
                .findFirstBySecret_IdAndStateOrderByVersionDesc(secret.getId(), "ACTIVE")
                .orElseThrow(() -> new IllegalStateException("No active secret version for: " + ref));

        String token = ref + ":" + version.getVersion();
        try (EphemeralSubjectDek dek = cryptoEngineService.unwrapDek(version.getWrappedDek())) {
            String value = cryptoEngineService.decryptValue(
                    version.getCiphertext(), version.getNonce(), dek,
                    SECRET_DATA_CLASS, ref, token);
            accessSignalEmitter.emit("USE_SECRET", SECRET_DATA_CLASS, null, "SUCCESS", 1);
            vaultEventEmitter.emitAccess("USE_SECRET", SECRET_DATA_CLASS, null, "SUCCESS", 1);
            auditRecorder.recordStrict("VAULT_SECRET_USED", "USE_SECRET", SECRET_DATA_CLASS, null, "SUCCESS", null, null);
            return UseSecretResponse.builder()
                    .ref(ref)
                    .value(value)
                    .version(version.getVersion())
                    .build();
        }
    }

    private String mintRef() {
        byte[] random = new byte[16];
        secureRandom.nextBytes(random);
        return "sec_" + HexFormat.of().formatHex(random);
    }
}
