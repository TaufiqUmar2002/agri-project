package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.keyManagement.RotationJob;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.RotateKeyRequest;
import com.umar.payload.response.vault.RotateKeyResponse;
import com.umar.repository.keyManagement.RotationJobRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class KeyRotationJobService {

    private final RotationJobRepository rotationJobRepository;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;

    @Transactional
    public RotateKeyResponse rotateKey(RotateKeyRequest request) {
        RotationJob job = new RotationJob();
        job.setId(UUID.randomUUID());
        job.setKeyType(request.getKeyType());
        job.setScope(request.getScope());
        job.setMode(request.getMode());
        job.setStatus("REQUESTED");
        job.setProgress("0%");

        RotationJob saved = rotationJobRepository.save(job);
        vaultEventEmitter.emit(VaultEventType.KEY_ROTATED, Map.of(
                "operation", "ROTATE_KEY",
                "keyType", request.getKeyType(),
                "scope", request.getScope(),
                "mode", request.getMode(),
                "jobId", saved.getId().toString()));
        auditRecorder.record("VAULT_KEY_ROTATED", "ROTATE_KEY", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    private RotateKeyResponse toResponse(RotationJob job) {
        return RotateKeyResponse.builder()
                .id(job.getId())
                .keyType(job.getKeyType())
                .scope(job.getScope())
                .mode(job.getMode())
                .status(job.getStatus())
                .build();
    }
}
