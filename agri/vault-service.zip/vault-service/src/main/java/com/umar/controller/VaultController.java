package com.umar.controller;

import com.umar.annotation.EnforceVaultPolicy;
import com.umar.approval.ApprovalService;
import com.umar.audit.AuditChainVerifier;
import com.umar.approval.DualControlGuard;
import com.umar.payload.request.vault.ApprovalDecisionRequest;
import com.umar.payload.request.vault.ApprovalRequest;
import com.umar.payload.request.vault.CreateBreakGlassRequest;
import com.umar.payload.request.vault.CreateLegalHoldRequest;
import com.umar.payload.request.vault.CreatePolicyRequest;
import com.umar.payload.request.vault.CreateSecretRequest;
import com.umar.payload.request.vault.DeTokenizeRequest;
import com.umar.payload.request.vault.DefineDataClassRequest;
import com.umar.payload.request.vault.RotateKeyRequest;
import com.umar.payload.request.vault.StoreDocumentRequest;
import com.umar.payload.request.vault.TokenizeRequest;
import com.umar.payload.request.vault.VerifyBackupRequest;
import com.umar.payload.response.vault.AccessRecordResponse;
import com.umar.payload.response.vault.ApprovalResponse;
import com.umar.payload.response.vault.BackupRunResponse;
import com.umar.payload.response.vault.BreakGlassResponse;
import com.umar.payload.response.vault.DataClassResponse;
import com.umar.payload.response.vault.DetokenizeResponse;
import com.umar.payload.response.vault.DocumentResponse;
import com.umar.payload.response.vault.DownloadDocumentResponse;
import com.umar.payload.response.vault.EraseSubjectResponse;
import com.umar.payload.response.vault.LegalHoldResponse;
import com.umar.payload.response.vault.PolicyResponse;
import com.umar.payload.response.vault.RotateKeyResponse;
import com.umar.payload.response.vault.SecretResponse;
import com.umar.payload.response.vault.TokenizeResponse;
import com.umar.payload.response.vault.UseSecretResponse;
import com.umar.service.AccessLogService;
import com.umar.service.BackupService;
import com.umar.service.BreakGlassService;
import com.umar.service.IVaultService;
import com.umar.service.DataClassDefinitionService;
import com.umar.service.DocumentService;
import com.umar.service.ErasureService;
import com.umar.service.KeyRotationJobService;
import com.umar.service.LegalHoldService;
import com.umar.security.DenyVaultRole;
import com.umar.security.RequireVaultRole;
import com.umar.security.VaultRole;
import com.umar.service.PolicyManagementService;
import com.umar.service.SecretService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/vault")
@RequiredArgsConstructor
public class VaultController {


    private final IVaultService tokenizationService;
    private final PolicyManagementService policyManagementService;
    private final ApprovalService approvalService;
    private final LegalHoldService legalHoldService;
    private final ErasureService erasureService;
    private final BreakGlassService breakGlassService;
    private final BackupService backupService;
    private final AccessLogService accessLogService;
    private final SecretService secretService;
    private final KeyRotationJobService keyRotationJobService;
    private final DocumentService documentService;
    private final DataClassDefinitionService dataClassDefinitionService;
    private final DualControlGuard dualControlGuard;
    private final AuditChainVerifier auditChainVerifier;

    @PostMapping("/tokenize")
    @EnforceVaultPolicy(
            dataClass = "#request.dataClass",
            purpose = "#request.purpose",
            operation = "TOKENIZE"
            )
    public ResponseEntity<TokenizeResponse> processTokenization(@RequestHeader("Idempotency-Key") String idempotencyKey,@RequestBody @Valid TokenizeRequest request) {
        try{
            TokenizeResponse response = tokenizationService.processTokenization(idempotencyKey, request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
        finally {
            for (TokenizeRequest.Items item : request.getItems()) {
                if (item.getValue() != null) {
                    Arrays.fill(item.getValue(), '\0');
                }
            }
        }
    }

    @PostMapping("/detokenize")
    @EnforceVaultPolicy(
            operation = "DETOKENIZE"
    )
    @DenyVaultRole(roles = {VaultRole.SECURITY_OFFICER, VaultRole.KEY_CUSTODIAN, VaultRole.AUDITOR, VaultRole.PLATFORM_RELIABILITY_ENGINEER, VaultRole.ADMINISTRATOR})
    public ResponseEntity<DetokenizeResponse> processDeTokenization(@RequestHeader("Request-Id") String requestId, @Valid @RequestBody DeTokenizeRequest request){
        DetokenizeResponse response = this.tokenizationService.processDeTokenization(requestId,request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @PostMapping("/secrets")
    @EnforceVaultPolicy(
            operation = "CREATE_SECRET"
    )
    public ResponseEntity<SecretResponse> createSecret(@RequestBody @Valid CreateSecretRequest request){
        SecretResponse response = secretService.createSecret(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/keys/rotate")
    @EnforceVaultPolicy(
            operation = "ROTATE_KEY"
    )
    @RequireVaultRole(operation = "ROTATE_KEY")
    public ResponseEntity<RotateKeyResponse> rotateKey(@RequestHeader("X-Approval-Id") String approvalId, @RequestBody @Valid RotateKeyRequest request){
        dualControlGuard.requireApprovedApproval(approvalId, "KEY_ACTION");
        RotateKeyResponse response = keyRotationJobService.rotateKey(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @PostMapping("/data-classes")
    @EnforceVaultPolicy(
            operation = "DEFINE_DATA_CLASS"
    )
    @RequireVaultRole(operation = "DEFINE_DATA_CLASS")
    public ResponseEntity<DataClassResponse> defineDataClass(@RequestBody @Valid DefineDataClassRequest request){
        DataClassResponse response = dataClassDefinitionService.defineDataClass(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/documents")
    @EnforceVaultPolicy(
            operation = "STORE_DOCUMENT"
    )
    public ResponseEntity<DocumentResponse> storeDocument(@RequestBody @Valid StoreDocumentRequest request){
        DocumentResponse response = documentService.storeDocument(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/documents")
    @EnforceVaultPolicy(
            operation = "LIST_DOCUMENTS"
    )
    public ResponseEntity<List<DocumentResponse>> listDocuments(
            @RequestParam(required = false) String dataClass,
            @RequestParam(required = false) String subjectRef){
        return ResponseEntity.ok(documentService.listDocuments(dataClass, subjectRef));
    }

    @GetMapping("/documents/{token}")
    @EnforceVaultPolicy(
            operation = "GET_DOCUMENT_METADATA"
    )
    public ResponseEntity<DocumentResponse> getDocumentMetadata(@PathVariable String token){
        return ResponseEntity.ok(documentService.getDocumentMetadata(token));
    }

    @DeleteMapping("/documents/{token}")
    @EnforceVaultPolicy(
            operation = "DELETE_DOCUMENT"
    )
    public ResponseEntity<Void> deleteDocument(@PathVariable String token){
        documentService.deleteDocument(token);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/break-glass")
    @EnforceVaultPolicy(
            operation = "BREAK_GLASS"
    )
    @RequireVaultRole(operation = "BREAK_GLASS")
    public ResponseEntity<BreakGlassResponse> breakGlass(@RequestHeader("X-Approval-Id") String approvalId, @RequestBody @Valid CreateBreakGlassRequest request){
        dualControlGuard.requireApprovedApproval(approvalId, "BREAK_GLASS");
        BreakGlassResponse response = breakGlassService.createBreakGlassRequest(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @PostMapping("/subjects/{id}/erase")
    @EnforceVaultPolicy(
            operation = "ERASE_SUBJECT"
    )
    @RequireVaultRole(operation = "ERASE_SUBJECT")
    public ResponseEntity<EraseSubjectResponse> eraseSubject(@PathVariable String id){
        EraseSubjectResponse response = erasureService.eraseSubject(id);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/legal-holds")
    @EnforceVaultPolicy(
            operation = "CREATE_LEGAL_HOLD"
    )
    @RequireVaultRole(operation = "CREATE_LEGAL_HOLD")
    public ResponseEntity<LegalHoldResponse> createLegalHold(@RequestBody @Valid CreateLegalHoldRequest request){
        LegalHoldResponse response = legalHoldService.createLegalHold(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/legal-holds/{id}/lift")
    @EnforceVaultPolicy(
            operation = "LIFT_LEGAL_HOLD"
    )
    @RequireVaultRole(operation = "LIFT_LEGAL_HOLD")
    public ResponseEntity<LegalHoldResponse> liftLegalHold(@RequestHeader("X-Approval-Id") String approvalId, @PathVariable UUID id){
        dualControlGuard.requireApprovedApproval(approvalId, "LEGAL_HOLD_LIFT");
        return ResponseEntity.ok(legalHoldService.liftLegalHold(id));
    }

    @PostMapping("/subjects/{id}/erasure-exception")
    @EnforceVaultPolicy(
            operation = "APPROVE_ERASURE_EXCEPTION"
    )
    @RequireVaultRole(operation = "APPROVE_ERASURE_EXCEPTION")
    public ResponseEntity<EraseSubjectResponse> erasureException(@RequestHeader("X-Approval-Id") String approvalId, @PathVariable String id, @RequestParam(required = false) String reason){
        dualControlGuard.requireApprovedApproval(approvalId, "ERASURE_EXCEPTION");
        return ResponseEntity.status(HttpStatus.CREATED).body(erasureService.recordErasureException(id, reason));
    }

    @GetMapping("/audit/verify")
    @RequireVaultRole(operation = "VERIFY_AUDIT")
    public ResponseEntity<AuditChainVerifier.VerificationResult> verifyAuditChain(){
        return ResponseEntity.ok(auditChainVerifier.verify());
    }

    @GetMapping("/access-log")
    @EnforceVaultPolicy(
            operation = "ACCESS_LOG"
    )
    @RequireVaultRole(operation = "ACCESS_LOG")
    public ResponseEntity<List<AccessRecordResponse>> getAccessLog(){
        return ResponseEntity.ok(accessLogService.getAccessLog());
    }

    @PostMapping("/backups/verify")
    @EnforceVaultPolicy(
            operation = "VERIFY_BACKUP"
    )
    @RequireVaultRole(operation = "VERIFY_BACKUP")
    public ResponseEntity<BackupRunResponse> verifyBackup(@RequestBody(required = false) VerifyBackupRequest request){
        BackupRunResponse response = backupService.verifyBackup(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/vault/policies")
    @EnforceVaultPolicy(
            operation = "CREATE_POLICY"
    )
    @RequireVaultRole(operation = "CREATE_POLICY")
    public ResponseEntity<PolicyResponse> createPolicy(@RequestHeader("X-Approval-Id") String approvalId, @RequestBody @Valid CreatePolicyRequest request){
        dualControlGuard.requireApprovedApproval(approvalId, "POLICY_CHANGE");
        PolicyResponse response = policyManagementService.createPolicy(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/vault/policies")
    @EnforceVaultPolicy(
            operation = "LIST_POLICIES"
    )
    public ResponseEntity<List<PolicyResponse>> listPolicies(){
        return ResponseEntity.ok(policyManagementService.listPolicies());
    }

    @PostMapping("/approvals/request")
    @EnforceVaultPolicy(
            operation = "REQUEST_APPROVAL"
    )
    public ResponseEntity<ApprovalResponse> requestApproval(@RequestBody @Valid ApprovalRequest request){
        ApprovalResponse response = approvalService.requestApproval(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PutMapping("/approvals/{approvalId}/decision")
    @EnforceVaultPolicy(
            operation = "APPROVAL_DECISION"
    )
    public ResponseEntity<ApprovalResponse> updateApprovalDecision(@PathVariable UUID approvalId,
                                                                   @RequestBody @Valid ApprovalDecisionRequest request){
        ApprovalResponse response = approvalService.recordDecision(approvalId, request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/documents/{token}")
    @EnforceVaultPolicy(
            operation = "DOWNLOAD_DOCUMENT"
    )
    @DenyVaultRole(roles = {VaultRole.SECURITY_OFFICER, VaultRole.KEY_CUSTODIAN, VaultRole.AUDITOR, VaultRole.PLATFORM_RELIABILITY_ENGINEER, VaultRole.ADMINISTRATOR})
    public ResponseEntity<DownloadDocumentResponse> downloadDocument(@PathVariable String token){
        DownloadDocumentResponse response = documentService.downloadDocument(token);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/secrets/{ref}/use")
    @EnforceVaultPolicy(
            operation = "USE_SECRET"
    )
    @DenyVaultRole(roles = {VaultRole.SECURITY_OFFICER, VaultRole.KEY_CUSTODIAN, VaultRole.AUDITOR, VaultRole.PLATFORM_RELIABILITY_ENGINEER, VaultRole.ADMINISTRATOR})
    public ResponseEntity<UseSecretResponse> useSecret(@PathVariable String ref){
        UseSecretResponse response = secretService.useSecret(ref);
        return ResponseEntity.ok(response);
    }
}
