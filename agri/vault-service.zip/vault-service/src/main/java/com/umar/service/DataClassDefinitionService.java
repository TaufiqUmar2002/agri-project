package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.dataProtection.DataClass;
import com.umar.hooks.DataClassDefinition;
import com.umar.hooks.DataClassHookDispatcher;
import com.umar.payload.request.vault.DefineDataClassRequest;
import com.umar.payload.response.vault.DataClassResponse;
import com.umar.repository.dataProtection.DataClassRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * Defines new data classes. Runs the {@code vault.data-class} extension point so
 * platform teams can contribute validation and masking rules before persistence.
 */
@Service
@RequiredArgsConstructor
public class DataClassDefinitionService {

    private final DataClassHookDispatcher hookDispatcher;
    private final DataClassRepository dataClassRepository;
    private final AuditRecorder auditRecorder;

    @Transactional
    public DataClass defineDataClass(DataClassDefinition definition) {
        // Let registered vault.data-class hooks contribute/override rules.
        hookDispatcher.dispatch(definition);

        DataClass dataClass = DataClass.builder()
                .id(UUID.randomUUID())
                .name(definition.getName())
                .valueKind(definition.getValueKind())
                .validation(definition.getValidation())
                .maskingRules(definition.getMaskingRules())
                .classification(definition.getClassification())
                .retentionGroup(definition.getRetentionGroup())
                .hasLookupHash(definition.getHasLookupHash())
                .blindIndex(definition.getBlindIndex())
                .fpe(definition.getFpe())
                .detokenizable(definition.getDetokenizable())
                .allowedPurposes(definition.getAllowedPurposes())
                .version(definition.getVersion())
                .status(definition.getStatus() != null ? definition.getStatus() : "ACTIVE")
                .build();

        DataClass saved = dataClassRepository.save(dataClass);
        auditRecorder.record("VAULT_DATA_CLASS_DEFINED", "DEFINE_DATA_CLASS", saved.getName(), null, "SUCCESS", null, null);
        return saved;
    }

    @Transactional
    public DataClassResponse defineDataClass(DefineDataClassRequest request) {
        DataClassDefinition definition = DataClassDefinition.builder()
                .name(request.getName())
                .valueKind(request.getValueKind())
                .classification(request.getClassification())
                .retentionGroup(request.getRetentionGroup())
                .hasLookupHash(request.getHasLookupHash())
                .blindIndex(request.getBlindIndex())
                .fpe(request.getFpe())
                .detokenizable(request.getDetokenizable())
                .allowedPurposes(request.getAllowedPurposes())
                .version(request.getVersion() != null ? request.getVersion() : 1)
                .status(request.getStatus())
                .build();

        DataClass saved = defineDataClass(definition);
        return toResponse(saved);
    }

    private DataClassResponse toResponse(DataClass dataClass) {
        return DataClassResponse.builder()
                .id(dataClass.getId())
                .name(dataClass.getName())
                .valueKind(dataClass.getValueKind())
                .classification(dataClass.getClassification())
                .retentionGroup(dataClass.getRetentionGroup())
                .detokenizable(dataClass.getDetokenizable())
                .allowedPurposes(dataClass.getAllowedPurposes())
                .version(dataClass.getVersion())
                .status(dataClass.getStatus())
                .build();
    }
}
