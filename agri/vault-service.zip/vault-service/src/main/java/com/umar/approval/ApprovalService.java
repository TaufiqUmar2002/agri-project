package com.umar.approval;

import com.umar.entity.governance.Approval;
import com.umar.exception.PolicyViolationException;
import com.umar.payload.request.vault.ApprovalDecisionRequest;
import com.umar.payload.request.vault.ApprovalRequest;
import com.umar.payload.response.vault.ApprovalResponse;
import com.umar.security.RoleAuthorizationService;
import com.umar.security.VaultRole;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ApprovalService {

    private static final Map<String, List<VaultRole>> TYPE_REQUIRED_ROLES = Map.of(
            "BREAK_GLASS", List.of(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER),
            "POLICY_CHANGE", List.of(VaultRole.SECURITY_OFFICER, VaultRole.COMPLIANCE_OFFICER),
            "KEY_ACTION", List.of(VaultRole.KEY_CUSTODIAN),
            "LEGAL_HOLD_LIFT", List.of(VaultRole.COMPLIANCE_OFFICER),
            "ERASURE_EXCEPTION", List.of(VaultRole.COMPLIANCE_OFFICER)
    );

    private final ApprovalRepository approvalRepository;
    private final RoleAuthorizationService roleAuthorizationService;

    /**
     * Creates a pending approval request from an {@link ApprovalRequest}, deriving
     * required roles from the approval type when not explicitly supplied.
     */
    @Transactional
    public ApprovalResponse requestApproval(ApprovalRequest request) {
        List<VaultRole> requiredRoles;
        if (request.getRequiredRoles() != null && !request.getRequiredRoles().isBlank()) {
            requiredRoles = Arrays.stream(request.getRequiredRoles().split(","))
                    .map(String::trim)
                    .map(this::toRole)
                    .filter(java.util.Objects::nonNull)
                    .collect(Collectors.toList());
        } else {
            requiredRoles = TYPE_REQUIRED_ROLES.getOrDefault(
                    request.getType().toUpperCase(), List.of());
        }
        int requiredApprovals = request.getRequiredApprovals() != null && request.getRequiredApprovals() > 0
                ? request.getRequiredApprovals() : 1;
        return requestApproval(request.getType(), request.getSubjectId(), request.getSubjectHash(), requiredRoles, requiredApprovals);
    }

    /**
     * Creates a pending approval request for a sensitive action (dual control).
     * The requester is the current caller. {@code requiredApprovals} is the N in
     * the N-of-M chain: the request becomes APPROVED only after that many distinct
     * approvers vote APPROVE.
     */
    @Transactional
    public ApprovalResponse requestApproval(String type, String subjectId, String subjectHash,
                                            List<VaultRole> requiredRoles, int requiredApprovals) {
        Approval approval = new Approval();
        approval.setId(UUID.randomUUID());
        approval.setType(type);
        approval.setSubjectId(subjectId);
        approval.setSubjectHash(subjectHash);
        approval.setRequiredRoles(requiredRoles.stream().map(Enum::name).collect(Collectors.joining(",")));
        approval.setRequestedBy(roleAuthorizationService.getCaller());
        approval.setRequiredApprovals(Math.max(1, requiredApprovals));
        approval.setApprovalCount(0);
        approval.setStatus("PENDING");

        Approval saved = approvalRepository.save(approval);
        return toResponse(saved);
    }

    /**
     * Records one approver's vote in the chain. A REJECT short-circuits to
     * REJECTED. APPROVE votes accumulate; once {@code approvalCount} reaches
     * {@code requiredApprovals} the request becomes APPROVED. The same approver
     * cannot vote twice, and no approver may approve their own request.
     */
    @Transactional
    public ApprovalResponse recordDecision(UUID approvalId, ApprovalDecisionRequest request) {
        Approval approval = approvalRepository.findById(approvalId)
                .orElseThrow(() -> new IllegalArgumentException("Approval not found: " + approvalId));

        if (!"PENDING".equalsIgnoreCase(approval.getStatus())) {
            throw new IllegalStateException("Approval is not pending a decision: " + approval.getStatus());
        }

        String approver = roleAuthorizationService.getCaller();

        // Dual control: an approver may never approve their own request.
        if (approver.equalsIgnoreCase(approval.getRequestedBy())) {
            throw new PolicyViolationException(
                    "Dual control violation: approver cannot approve their own request");
        }

        // Verify the approver holds one of the required roles.
        List<VaultRole> required = parseRoles(approval.getRequiredRoles());
        if (!required.isEmpty()) {
            roleAuthorizationService.requireAnyRole(required.toArray(new VaultRole[0]));
        }

        // Prevent the same approver from voting twice.
        List<String> decisions = approval.getDecisions() != null
                ? new ArrayList<>(approval.getDecisions())
                : new ArrayList<>();
        if (decisions.stream().anyMatch(d -> d.startsWith(approver + ":"))) {
            throw new PolicyViolationException("Approver has already recorded a decision for this approval");
        }

        boolean approve = "APPROVE".equalsIgnoreCase(request.getDecision());
        decisions.add(approver + ":" + request.getDecision());
        approval.setDecisions(decisions);

        if (!approve) {
            // Any REJECT short-circuits the chain.
            approval.setDecision(request.getDecision());
            approval.setDecidedBy(approver);
            approval.setDecidedAt(Instant.now());
            approval.setStatus("REJECTED");
        } else {
            approval.setApprovalCount(approval.getApprovalCount() + 1);
            if (approval.getApprovalCount() >= approval.getRequiredApprovals()) {
                approval.setDecision("APPROVE");
                approval.setDecidedBy(approver);
                approval.setDecidedAt(Instant.now());
                approval.setStatus("APPROVED");
            }
            // Otherwise the request remains PENDING awaiting further approvals.
        }

        Approval saved = approvalRepository.save(approval);
        return toResponse(saved);
    }

    private List<VaultRole> parseRoles(String requiredRoles) {
        if (requiredRoles == null || requiredRoles.isBlank()) {
            return List.of();
        }
        return Arrays.stream(requiredRoles.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(this::toRole)
                .filter(java.util.Objects::nonNull)
                .collect(Collectors.toList());
    }

    private VaultRole toRole(String raw) {
        try {
            return VaultRole.valueOf(raw.trim().toUpperCase().replace('-', '_').replace(' ', '_'));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private ApprovalResponse toResponse(Approval approval) {
        return ApprovalResponse.builder()
                .id(approval.getId())
                .type(approval.getType())
                .subjectId(approval.getSubjectId())
                .status(approval.getStatus())
                .decision(approval.getDecision())
                .decidedBy(approval.getDecidedBy())
                .decidedAt(approval.getDecidedAt())
                .decisions(approval.getDecisions())
                .requiredApprovals(approval.getRequiredApprovals())
                .approvalCount(approval.getApprovalCount())
                .build();
    }
}