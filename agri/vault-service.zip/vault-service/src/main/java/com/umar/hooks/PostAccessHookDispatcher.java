package com.umar.hooks;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Dispatches {@code vault.post-access} signals to every registered
 * {@link VaultPostAccessHook} bean. Hook failures are logged but never
 * propagated, so access operations are not affected.
 */
@Slf4j
@Component
public class PostAccessHookDispatcher {

    private final List<VaultPostAccessHook> hooks;

    public PostAccessHookDispatcher(List<VaultPostAccessHook> hooks) {
        this.hooks = hooks;
    }

    public void dispatch(AccessSignal signal) {
        for (VaultPostAccessHook hook : hooks) {
            try {
                hook.onAccess(signal);
            } catch (Exception e) {
                log.error("vault.post-access hook {} failed for signal {}",
                        hook.getClass().getName(), signal, e);
            }
        }
    }
}
