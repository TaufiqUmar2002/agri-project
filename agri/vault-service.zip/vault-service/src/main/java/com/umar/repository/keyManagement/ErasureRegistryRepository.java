package com.umar.repository.keyManagement;

import com.umar.entity.keyManagement.ErasureRegistry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ErasureRegistryRepository extends JpaRepository<ErasureRegistry, UUID> {
}
