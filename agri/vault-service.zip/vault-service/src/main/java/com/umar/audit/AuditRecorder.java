package com.umar.audit;

import com.umar.authentication.VaultSecurityContext;
import com.umar.authentication.WorkloadIdentity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * Builds and records {@link AuditEvent}s for vault operations. Recording is
 * best-effort: failures are logged but never break the operation. For operations
 * that release sensitive data, callers may use {@link #recordStrict} to make
 * audit mandatory.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditRecorder {

    private final AuditService auditService;

    /** Best-effort audit record; never throws. */
    public void record(String eventType, String operation, String dataClass,
                       String purpose, String outcome, UUID resourceId, String errorCode) {
        try {
            auditService.recordAndRequireDurable(build(eventType, operation, dataClass, purpose, outcome, resourceId, errorCode));
        } catch (Exception e) {
            log.error("Audit recording failed for operation {}: {}", operation, e.getMessage());
        }
    }

    /** Strict audit record; throws {@link AuditException} on failure. */
    public void recordStrict(String eventType, String operation, String dataClass,
                             String purpose, String outcome, UUID resourceId, String errorCode) {
        auditService.recordAndRequireDurable(build(eventType, operation, dataClass, purpose, outcome, resourceId, errorCode));
    }

    private AuditEvent build(String eventType, String operation, String dataClass,
                             String purpose, String outcome, UUID resourceId, String errorCode) {
        WorkloadIdentity identity = VaultSecurityContext.getWorkloadIdentity();
        String caller = identity != null ? identity.serviceName() : "UNKNOWN";
        String callerIdentity = identity != null ? identity.serviceName() + "/" + identity.environment() : "UNKNOWN";

        return new AuditEvent(
                UUID.randomUUID(),
                eventType,
                operation,
                caller,
                callerIdentity,
                purpose,
                dataClass,
                null,
                null,
                resourceId,
                null,
                outcome,
                errorCode,
                Instant.now());
    }
}
