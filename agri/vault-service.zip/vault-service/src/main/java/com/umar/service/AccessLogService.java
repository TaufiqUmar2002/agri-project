package com.umar.service;

import com.umar.entity.auditAndAccess.AccessRecord;
import com.umar.payload.response.vault.AccessRecordResponse;
import com.umar.repository.auditAndAccess.AccessRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AccessLogService {

    private final AccessRecordRepository accessRecordRepository;

    @Transactional(readOnly = true)
    public List<AccessRecordResponse> getAccessLog() {
        return accessRecordRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    private AccessRecordResponse toResponse(AccessRecord record) {
        return AccessRecordResponse.builder()
                .id(record.getId())
                .caller(record.getCaller())
                .operation(record.getOperation())
                .dataClass(record.getDataClass())
                .purpose(record.getPurpose())
                .outcome(record.getOutcome())
                .timestamp(record.getTimestamp())
                .build();
    }
}
