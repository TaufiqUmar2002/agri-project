package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.authentication.VaultSecurityContext;
import com.umar.blindindex.BlindIndexService;
import com.umar.authentication.WorkloadIdentity;
import com.umar.config.EphemeralSubjectDek;
import com.umar.crypto.*;
import com.umar.entity.dataProtection.VaultToken;
import com.umar.events.VaultEventType;
import com.umar.idempotency.IdempotencyClaim;
import com.umar.idempotency.IdempotencyControllerAdvice;
import com.umar.idempotency.IdempotencyService;
import com.umar.payload.request.vault.DeTokenizeRequest;
import com.umar.policy.PolicyResource;
import com.umar.policy.VaultPolicyService;
import com.umar.payload.request.vault.TokenizeRequest;
import com.umar.payload.response.vault.DetokenizeResponse;
import com.umar.payload.response.vault.ItemFailure;
import com.umar.payload.response.vault.ResolvedValue;
import com.umar.payload.response.vault.TokenFailure;
import com.umar.payload.response.vault.TokenSuccess;
import com.umar.payload.response.vault.TokenizeResponse;
import com.umar.repository.dataProtection.VaultTokenRepository;
import com.umar.util.TokenGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class VaultService implements IVaultService{

    private final VaultTokenRepository tokenRepository;
    private final TokenGenerator tokenGenerator;
    private final CryptoEngineService cryptoEngineService;
    private final ValidationRegistryService validatorService;
    private final CryptoService cryptoService;
    private final VaultPolicyService vaultPolicyService;
    private final AccessSignalEmitter accessSignalEmitter;
    private final VaultEventEmitter vaultEventEmitter;
    private final IdempotencyService idempotencyService;
    private final AuditRecorder auditRecorder;
    private final BlindIndexService blindIndexService;
//    private final DataEncryptionKeyProvider keyProvider;

    @Override
    public TokenizeResponse processTokenization(String idempotencyKey, TokenizeRequest request) {
        UUID key = parseIdempotencyKey(idempotencyKey);
        if (key == null) {
            return doTokenize(request);
        }

        String caller = resolveCaller();
        String owner = UUID.randomUUID().toString();
        IdempotencyClaim claim = idempotencyService.claim(
                caller, IdempotencyService.TOKENIZE_OPERATION, key, request, owner);

        return switch (claim.type()) {
            case REPLAY -> idempotencyService.deserializeReplay(claim.responsePayload(), TokenizeResponse.class);
            case IN_PROGRESS -> throw new IdempotencyControllerAdvice.IdempotencyInProgressException(
                    "Request with this idempotency key is still being processed");
            case PAYLOAD_CONFLICT -> throw new IdempotencyControllerAdvice.IdempotencyConflictException(
                    "Idempotency key reused with a different request payload");
            case NEW_REQUEST -> {
                try {
                    TokenizeResponse response = doTokenize(request);
                    idempotencyService.complete(claim.recordId(), owner, response, 200);
                    yield response;
                } catch (Exception e) {
                    idempotencyService.markFailed(claim.recordId(), owner);
                    throw e;
                }
            }
        };
    }

    private TokenizeResponse doTokenize(TokenizeRequest request) {
        String operationRequestId = "req_" + UUID.randomUUID().toString().replace("-", "");
        List<TokenSuccess> successList = new ArrayList<>();
        List<ItemFailure> failureList = new ArrayList<>();
//        EphemeralSubjectDek ephemeralSubjectDek = new EphemeralSubjectDek();
        for (int index = 0; index < request.getItems().size(); index++) {
            TokenizeRequest.Items item = request.getItems().get(index);
            if (!validatorService.isValidForClass(item.getValue(), item.getDataClass())) {
                failureList.add(new ItemFailure(index, "VALUE_INVALID", "Value fails the structural verification constraints of class"));
                continue;
            }
            boolean reuse = (item.getReuseExisting() == null) || item.getReuseExisting();
            if (reuse) {
                Optional<VaultToken> existingToken = tokenRepository.findExistingMatch(item.getSubjectRef(), item.getDataClass());
                if (existingToken.isPresent()) {
                    VaultToken t = existingToken.get();
                    successList.add(new TokenSuccess(index, t.getToken(), t.getDataClass(), t.getMaskedForm(), true, t.getFormat(), t.getCreatedAt()));
                    continue;
                }
            }
            // FPE Restriction Verification Check (Scenario 4)
            if ("FPE".equalsIgnoreCase(item.getFormat().name()) && !validatorService.isFpePermitted(item.getDataClass())) {
                failureList.add(new ItemFailure(index, "FPE_NOT_ALLOWED", "Format preserving option unavailable for data class allocation"));
                continue;
            }

            // Step 4 & 6: Resolve Keys & Execute Cipher operations inside clearable memory
            try (EphemeralSubjectDek activeDek = cryptoEngineService.generateEphemeralDek()) {
                String mintedTokenStr = tokenGenerator.mintTokenString(item.getDataClass(), false);
                String hint = tokenGenerator.createMaskedHint(mintedTokenStr);

                var cryptoPayload = cryptoEngineService.encryptValue(
                        item.getValue(), activeDek, item.getDataClass(), item.getSubjectRef(), mintedTokenStr
                );
                    VaultToken newToken = VaultToken.builder()
                            .id(UUID.randomUUID())
                            .token(mintedTokenStr)
                            .dataClass(item.getDataClass())
                            .subjectRef(item.getSubjectRef())
                            .retentionGroup("ERASABLE")
                            .ciphertext(cryptoPayload.ciphertext())
                            .nonce(cryptoPayload.nonce())
                            .keyVersion(cryptoPayload.keyVersion())
                            .wrappedDek(cryptoEngineService.wrapDek(activeDek))
                            .maskedForm(hint)
                            .format("OPAQUE")
                            .createdAt(Instant.now())
                            .build();
                // Step 7 & 8: Store encrypted token state blocks and bind index records
                tokenRepository.save(newToken);
                blindIndexService.saveActiveIndex(item.getDataClass(), item.getSubjectRef(), newToken.getId(), new String(item.getValue()));
                successList.add(new TokenSuccess(index, mintedTokenStr, item.getDataClass(), hint, false, "OPAQUE", newToken.getCreatedAt()));
            }
        }
        // 2. Resolve active DEK for subject and data class
//        DataEncryptionKeyProvider.KeyMaterial keyMaterial = keyProvider.getEncryptionKey(
//                request.subjectRef(),
//                request.dataClass()
//        );

        // 3. Build authenticated encryption context
//        EncryptionContext context = new EncryptionContext(
//                request.dataClass(),
//                request.subjectRef(),
//                token
//        );

        // 4. Encrypt plaintext
//        EncryptedPayload encryptedPayload = cryptoService.encrypt(
//                request.value(),
//                keyMaterial.key(),
//                context
//        );

        // 5. Persist only ciphertext, nonce and key metadata
//        VaultToken vaultToken = new VaultToken(
//                token,
//                request.dataClass(),
//                request.subjectRef(),
//                encryptedPayload.ciphertext(),
//                encryptedPayload.nonce(),
//                keyMaterial.keyVersionId()
//        );

        // 6. Save encrypted record
//        VaultToken savedToken = tokenRepository.save(vaultToken);

        // Step 9: Commit WORM Append Log Footprint and Emit Outbox telemetry
        // ... Log commitment steps go here ...

        accessSignalEmitter.emit("TOKENIZE", null, request.getPurpose(),
                failureList.isEmpty() ? "SUCCESS" : "PARTIAL", successList.size());

        vaultEventEmitter.emit(VaultEventType.TOKENIZED, Map.of(
                "operation", "TOKENIZE",
                "purpose", request.getPurpose(),
                "recordCount", successList.size(),
                "failureCount", failureList.size()));
        vaultEventEmitter.emitAccess("TOKENIZE", null, request.getPurpose(),
                failureList.isEmpty() ? "SUCCESS" : "PARTIAL", successList.size());

        auditRecorder.record("VAULT_TOKENIZED", "TOKENIZE", null, request.getPurpose(),
                failureList.isEmpty() ? "SUCCESS" : "PARTIAL", null, null);

        return new TokenizeResponse(successList, failureList, operationRequestId);
    }

    @Override
    public DetokenizeResponse processDeTokenization(String requestId, DeTokenizeRequest request) {
        List<ResolvedValue> values = new ArrayList<>();
        List<TokenFailure> failures = new ArrayList<>();

        // Load all token records first so per-token-class policy can be enforced
        // before any plaintext is released.
        List<VaultToken> records = new ArrayList<>();
        for (String token : request.getTokens()) {
            Optional<VaultToken> tokenRecord = tokenRepository.findByToken(token);
            if (tokenRecord.isEmpty()) {
                failures.add(TokenFailure.builder().token(token).code("TOKEN_NOT_FOUND").build());
                continue;
            }
            records.add(tokenRecord.get());
        }

        // Enforce DETOKENIZE policy for every resolved data class up front.
        List<PolicyResource> resources = records.stream()
                .map(record -> new PolicyResource(record.getDataClass(), request.getPurpose()))
                .distinct()
                .toList();
        if (!resources.isEmpty()) {
            vaultPolicyService.authorize("DETOKENIZE", resources);
        }

        for (VaultToken record : records) {
            String token = record.getToken();
            if (record.getWrappedDek() == null) {
                failures.add(TokenFailure.builder().token(token).code("KEY_UNAVAILABLE").build());
                continue;
            }
            try (EphemeralSubjectDek dek = cryptoEngineService.unwrapDek(record.getWrappedDek())) {
                String value = cryptoEngineService.decryptValue(
                        record.getCiphertext(), record.getNonce(), dek,
                        record.getDataClass(), record.getSubjectRef(), record.getToken());
                values.add(ResolvedValue.builder()
                        .token(token)
                        .dataClass(record.getDataClass())
                        .value(value)
                        .build());
            } catch (Exception e) {
                log.warn("Detokenization failed for token {}: {}", token, e.getMessage());
                failures.add(TokenFailure.builder().token(token).code("DECRYPTION_FAILED").build());
            }
        }

        accessSignalEmitter.emit("DETOKENIZE", null, request.getPurpose(),
                failures.isEmpty() ? "SUCCESS" : "PARTIAL", values.size());

        vaultEventEmitter.emitAccess("DETOKENIZE", null, request.getPurpose(),
                failures.isEmpty() ? "SUCCESS" : "PARTIAL", values.size());

        auditRecorder.recordStrict("VAULT_DETOKENIZED", "DETOKENIZE", null, request.getPurpose(),
                failures.isEmpty() ? "SUCCESS" : "PARTIAL", null, null);

        return DetokenizeResponse.builder()
                .values(values)
                .failures(failures)
                .requestId(requestId)
                .build();
    }

    private UUID parseIdempotencyKey(String key) {
        if (key == null || key.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(key);
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("Idempotency-Key must be a valid UUID");
        }
    }

    private String resolveCaller() {
        WorkloadIdentity identity = VaultSecurityContext.getWorkloadIdentity();
        return identity != null ? identity.serviceName() : "UNKNOWN";
    }
    }

//    8443