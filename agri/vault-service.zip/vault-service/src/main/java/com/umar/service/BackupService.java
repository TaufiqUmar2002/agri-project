package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.entity.governance.BackupRun;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.VerifyBackupRequest;
import com.umar.payload.response.vault.BackupRunResponse;
import com.umar.repository.governance.BackupRunRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BackupService {

    private final BackupRunRepository backupRunRepository;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;

    @Transactional
    public BackupRunResponse verifyBackup(VerifyBackupRequest request) {
        BackupRun run = new BackupRun();
        run.setId(UUID.randomUUID());
        run.setType("VERIFY");
        run.setBackupSetIds(request != null ? request.getBackupSetIds() : null);
        run.setFindings(request != null ? request.getFindings() : null);

        BackupRun saved = backupRunRepository.save(run);
        Map<String, Object> payload = new java.util.HashMap<>();
        payload.put("operation", "VERIFY_BACKUP");
        payload.put("backupSetIds", request != null ? request.getBackupSetIds() : null);
        payload.put("runId", saved.getId().toString());
        vaultEventEmitter.emit(VaultEventType.BACKUP_VERIFIED, payload);
        auditRecorder.record("VAULT_BACKUP_VERIFIED", "VERIFY_BACKUP", null, null, "SUCCESS", null, null);
        return toResponse(saved);
    }

    private BackupRunResponse toResponse(BackupRun run) {
        return BackupRunResponse.builder()
                .id(run.getId())
                .type(run.getType())
                .backupSetIds(run.getBackupSetIds())
                .findings(run.getFindings())
                .build();
    }
}
