package com.umar.service;

import com.umar.audit.AuditRecorder;
import com.umar.config.EphemeralSubjectDek;
import com.umar.crypto.CryptoEngineService;
import com.umar.entity.dataProtection.Document;
import com.umar.events.VaultEventType;
import com.umar.payload.request.vault.StoreDocumentRequest;
import com.umar.payload.response.vault.DocumentResponse;
import com.umar.payload.response.vault.DownloadDocumentResponse;
import com.umar.repository.dataProtection.DocumentRepository;
import com.umar.util.TokenGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DocumentService {

    private static final String DOCUMENT_DATA_CLASS = "DOCUMENT";

    private final DocumentRepository documentRepository;
    private final CryptoEngineService cryptoEngineService;
    private final TokenGenerator tokenGenerator;
    private final AccessSignalEmitter accessSignalEmitter;
    private final VaultEventEmitter vaultEventEmitter;
    private final AuditRecorder auditRecorder;
    private final SecureRandom secureRandom = new SecureRandom();

    @Transactional
    public DocumentResponse storeDocument(StoreDocumentRequest request) {
        String token = tokenGenerator.mintTokenString(request.getDataClass(), true);
        char[] cleartext = request.getContent().toCharArray();

        try (EphemeralSubjectDek dek = cryptoEngineService.generateEphemeralDek()) {
            var payload = cryptoEngineService.encryptValue(cleartext, dek, DOCUMENT_DATA_CLASS, request.getSubjectRef(), token);

            Document document = new Document();
            document.setId(UUID.randomUUID());
            document.setToken(token);
            document.setDataClass(request.getDataClass());
            document.setSubjectRef(request.getSubjectRef());
            document.setRetentionClass("ERASABLE");
            document.setContentType(request.getContentType());
            document.setSha256(sha256(request.getContent()));
            document.setSizeBytes(String.valueOf(request.getContent().getBytes(StandardCharsets.UTF_8).length));
            document.setEncryptedContent(payload.ciphertext());
            document.setNonce(payload.nonce());
            document.setWrappedDek(cryptoEngineService.wrapDek(dek));

            Document saved = documentRepository.save(document);
            accessSignalEmitter.emit("STORE_DOCUMENT", request.getDataClass(), request.getPurpose(), "SUCCESS", 1);
            vaultEventEmitter.emit(VaultEventType.TOKENIZED, Map.of(
                    "operation", "STORE_DOCUMENT",
                    "dataClass", request.getDataClass(),
                    "purpose", request.getPurpose(),
                    "recordCount", 1));
            vaultEventEmitter.emitAccess("STORE_DOCUMENT", request.getDataClass(), request.getPurpose(), "SUCCESS", 1);
            auditRecorder.record("VAULT_DOCUMENT_STORED", "STORE_DOCUMENT", request.getDataClass(), request.getPurpose(), "SUCCESS", null, null);
            return toResponse(saved);
        } finally {
            java.util.Arrays.fill(cleartext, '\0');
        }
    }

    @Transactional(readOnly = true)
    public DownloadDocumentResponse downloadDocument(String token) {
        Document document = documentRepository.findByToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Document not found: " + token));

        try (EphemeralSubjectDek dek = cryptoEngineService.unwrapDek(document.getWrappedDek())) {
            String content = cryptoEngineService.decryptValue(
                    document.getEncryptedContent(), document.getNonce(), dek,
                    DOCUMENT_DATA_CLASS, document.getSubjectRef(), document.getToken());
            accessSignalEmitter.emit("DOWNLOAD_DOCUMENT", document.getDataClass(), null, "SUCCESS", 1);
            vaultEventEmitter.emitAccess("DOWNLOAD_DOCUMENT", document.getDataClass(), null, "SUCCESS", 1);
            auditRecorder.recordStrict("VAULT_DOCUMENT_DOWNLOADED", "DOWNLOAD_DOCUMENT", document.getDataClass(), null, "SUCCESS", null, null);
            return DownloadDocumentResponse.builder()
                    .token(token)
                    .contentType(document.getContentType())
                    .content(content)
                    .build();
        }
    }

    @Transactional(readOnly = true)
    public List<DocumentResponse> listDocuments(String dataClass, String subjectRef) {
        List<Document> documents;
        if (dataClass != null && !dataClass.isBlank() && subjectRef != null && !subjectRef.isBlank()) {
            documents = documentRepository.findByDataClassAndSubjectRef(dataClass, subjectRef);
        } else if (dataClass != null && !dataClass.isBlank()) {
            documents = documentRepository.findByDataClass(dataClass);
        } else if (subjectRef != null && !subjectRef.isBlank()) {
            documents = documentRepository.findBySubjectRef(subjectRef);
        } else {
            documents = documentRepository.findAll();
        }
        return documents.stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public DocumentResponse getDocumentMetadata(String token) {
        Document document = documentRepository.findByToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Document not found: " + token));
        return toResponse(document);
    }

    @Transactional
    public void deleteDocument(String token) {
        Document document = documentRepository.findByToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Document not found: " + token));

        // Crypto-shred: destroy key material and ciphertext before removing the row.
        document.setEncryptedContent(null);
        document.setNonce(null);
        document.setWrappedDek(null);
        documentRepository.save(document);
        documentRepository.delete(document);

        accessSignalEmitter.emit("DELETE_DOCUMENT", document.getDataClass(), null, "SUCCESS", 1);
        auditRecorder.recordStrict("VAULT_DOCUMENT_DELETED", "DELETE_DOCUMENT", document.getDataClass(), null, "SUCCESS", null, null);
    }

    private String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to hash document content", e);
        }
    }

    private DocumentResponse toResponse(Document document) {
        return DocumentResponse.builder()
                .id(document.getId())
                .token(document.getToken())
                .dataClass(document.getDataClass())
                .subjectRef(document.getSubjectRef())
                .contentType(document.getContentType())
                .sizeBytes(document.getSizeBytes())
                .build();
    }
}
