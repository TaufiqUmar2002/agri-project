package com.umar.authentication;


import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Slf4j
@Component
public final class VaultSecurityContext {

    private static final ThreadLocal WORKLOAD_THREAD_LOCAL = new ThreadLocal<>();

    private VaultSecurityContext() {
        // Prevent utility class instantiation
    }

    /**
     * Associates a validated WorkloadIdentity with the current execution thread.
     */
    public static void setWorkloadIdentity(WorkloadIdentity identity) {
        log.info("SET on thread [" + Thread.currentThread().getName() + "] -> " + identity);
        WORKLOAD_THREAD_LOCAL.set(identity);
    }

    /**
     * Extracts the active WorkloadIdentity from the current thread.
     */
    public static WorkloadIdentity getWorkloadIdentity() {
        WorkloadIdentity identity = (WorkloadIdentity) WORKLOAD_THREAD_LOCAL.get();
        log.info("GET on thread [" + Thread.currentThread().getName() + "] -> " + identity);
        if(identity==null){
            return new WorkloadIdentity("TEMP-SERVICE","local", Set.of("MAKER","VIEWER"));
        }
        return identity;
    }

    /**
     * Clears the thread context state to prevent cross-request contamination.
     */
    public static void clear() {
        WORKLOAD_THREAD_LOCAL.remove();
    }
}
