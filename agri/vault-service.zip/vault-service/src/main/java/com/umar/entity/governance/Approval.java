package com.umar.entity.governance;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "APPROVAL")
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Approval {

    @Id
    private UUID id;

    private String  type;

    private String subjectId;

    private String subjectHash;

    private String requiredRoles;

    @Column(name = "REQUESTED_BY")
    private String requestedBy;

    @ElementCollection
    private List<String> decisions;

    @Column(name = "STATUS")
    private String status = "PENDING";

    @Column(name = "DECISION")
    private String decision;

    @Column(name = "DECIDED_BY")
    private String decidedBy;

    @Column(name = "DECIDED_AT")
    private Instant decidedAt;

    @Column(name = "REQUIRED_APPROVALS")
    private int requiredApprovals = 1;

    @Column(name = "APPROVAL_COUNT")
    private int approvalCount = 0;
}